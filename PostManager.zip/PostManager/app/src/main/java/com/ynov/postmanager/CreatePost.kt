package com.ynov.postmanager

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.squareup.moshi.Moshi
import okhttp3.*
import java.io.IOException


//android:parentActivityName=".MainActivity"
class CreatePost : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.post_create)
        val createPostButton = findViewById<Button>(R.id.createPostButton)


        Thread {
// set on-click listener
            createPostButton.setOnClickListener {
                createPost()

                val intent = Intent(this, MainActivity::class.java)

                startActivity(intent)
            }
        }.start()


    }

    private fun createPost() { // return JSONOBJECT else false

        val client = OkHttpClient()
        val moshi = Moshi.Builder().build()

        val imageLink = findViewById<EditText>(R.id.imageLinkText)
        val postContent = findViewById<EditText>(R.id.postContentText)
        val animalTag = findViewById<CheckBox>(R.id.checkBox2)
        val natureTag =findViewById<CheckBox>(R.id.checkBox6)
        val travelTag =findViewById<CheckBox>(R.id.checkBox5)
        val showsTag =findViewById<CheckBox>(R.id.checkBox7)
        val cookingTag =findViewById<CheckBox>(R.id.checkBox4)
        val hobbyTag=findViewById<CheckBox>(R.id.checkBox3)
        val workTag =findViewById<CheckBox>(R.id.checkBox)
        val literatureTag=findViewById<CheckBox>(R.id.checkBox8)
        val funTag =findViewById<CheckBox>(R.id.checkBox9)

        if ( imageLink.text.isBlank() or postContent.text.isBlank() )
        {
            Toast.makeText(this@CreatePost, "Please make sure to fill the whole form ", Toast.LENGTH_LONG).show()
        }
        else {

            var tags : MutableList<String> = arrayListOf()


            if (animalTag.isChecked) {

                tags.add("animal")
            }
            if (natureTag.isChecked) {

                tags.add("nature")

            }
            if (travelTag.isChecked) {

                tags.add("travel")
            }
            if (showsTag.isChecked) {

                tags.add("shows")

            }
            if (cookingTag.isChecked) {

                tags.add("cooking")
            }
            if (hobbyTag.isChecked) {

                tags.add("hobby")
            }
            if (workTag.isChecked) {

                tags.add("work")
            }
            if (literatureTag.isChecked) {

                tags.add("literature")
            }
            if (funTag.isChecked) {


                tags.add("fun")
            }


            val paramBuilder = FormBody.Builder()
            if (!tags.isEmpty()) {
                val entries = tags.iterator()
                while (entries.hasNext()) {

                    paramBuilder.add("tags", entries.next())
                }
            }
            paramBuilder
                .add("text", postContent.text.toString())
                .add("image", imageLink.text.toString())
                .add("likes", "5")
                .add("owner", "626b01037f5022c82e7c2149")


            val formBody: RequestBody = paramBuilder.build()

            val request = Request.Builder()
                .url("https://dummyapi.io/data/v1/post/create") //?page=2&limit=10?
                .addHeader("app-id","626474e1de86af0db21ad0d0")
                .post(formBody)
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    e.printStackTrace()
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        if (!response.isSuccessful) throw IOException("Unexpected code $response")
                for ((name, value) in response.headers) {
                            println("$name: $value")
                        }

                        println(response.body!!.string())


                    }


                }


            })
            Toast.makeText(this@CreatePost, "Post created successfully ", Toast.LENGTH_LONG).show()
        }



    }



}