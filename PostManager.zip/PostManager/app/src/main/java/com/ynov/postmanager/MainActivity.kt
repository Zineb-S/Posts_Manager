package com.ynov.postmanager

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.appcompat.widget.SearchView
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.*
import kotlin.collections.ArrayList


class MainActivity : AppCompatActivity()  {


    private lateinit var recycler : RecyclerView
    // okhttp
    private val client = OkHttpClient()

    // moshi
    private val moshi = Moshi.Builder().build()
    val listType = Types.newParameterizedType(List::class.java, Post::class.java)

    val moshiAdapter: JsonAdapter<List<Post>> = moshi.adapter(listType)

    val listType2 = Types.newParameterizedType(List::class.java, User::class.java)

    val moshiAdapter2: JsonAdapter<List<User>> = moshi.adapter(listType2)

    var  pListFull : MutableList<Post> = java.util.ArrayList<Post>()
    var  oListFull : MutableList<User> = java.util.ArrayList<User>()


    var  temppListFull : MutableList<Post> = java.util.ArrayList<Post>()
    var  tempoListFull : MutableList<User> = java.util.ArrayList<User>()




    // add interceptor so that all the requests contains the app id
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recycler = findViewById<RecyclerView>(R.id.recyclerView)
        recycler.layoutManager = LinearLayoutManager(this)
    val createPostButton = findViewById<Button>(R.id.createPostButton)
    val fab: View = findViewById(R.id.createPostFloatingActionButton)
    fab.setOnClickListener {
        val intent = Intent(this, CreatePost::class.java)



        startActivity(intent)
    }
        Thread {
            loadPostData();

        }.start()
    }





    fun loadPostData() {



        val request = Request.Builder()
            .url("https://dummyapi.io/data/v1/post") //?page=2&limit=10?
            .addHeader("app-id","626474e1de86af0db21ad0d0")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Unexpected code $response")



            val result = response.body!!.string()

            val Jobject = JSONObject(result)
            val Jarray: JSONArray = Jobject.getJSONArray("data")
            val posts = Jarray.toString()
            var postList: List<Post> = moshiAdapter.fromJson(posts) as List<Post>


            var array: JSONArray = Jarray
            var owners = JSONArray()
            for (n in 0 until array.length()) {
                val `object` = array.getJSONObject(n)
                val own = `object`.getJSONObject("owner")
                    owners.put(own)
            }

            var ownerList: List<User> = moshiAdapter2.fromJson(owners.toString()) as List<User>



            oListFull.addAll(ownerList)

            pListFull.addAll(postList)

            tempoListFull.addAll(ownerList)

            temppListFull.addAll(postList)


            println("3t9o ROOOOO7                   "+pListFull)




            val postAdapter = PostAdapter(temppListFull as MutableList<Post>,
                tempoListFull as MutableList<User>
            )

            var swipeGestureDelete = object : SwipeGesture(this)
            {
                override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {


                        postAdapter.deleteItem(viewHolder.absoluteAdapterPosition)
                    Toast.makeText(this@MainActivity, "Post deleted successfully ", Toast.LENGTH_LONG).show()





                }
            }

            postAdapter.setOnItemClickListener(object : PostAdapter.OnItemClickListener{
                override fun onItemClick(position: Int) {
                    val goToPostDetails = Intent(this@MainActivity, PostDetails::class.java)
                    goToPostDetails.putExtra("ownerPic",ownerList[position].picture)
                    goToPostDetails.putExtra("ownerName",ownerList[position].firstName+" "+ownerList[position].lastName)
                    goToPostDetails.putExtra("postContent",postList[position].text)
                    goToPostDetails.putExtra("postPicture",postList[position].image)
                    goToPostDetails.putExtra("postLikes",postList[position].likes)
                    goToPostDetails.putExtra("postTags",ArrayList(postList[position].tags) )
                    goToPostDetails.putExtra("postDate",postList[position].publishDate)
                    startActivity(goToPostDetails)


                }

            })

            runOnUiThread {


                val touchHelper = ItemTouchHelper(swipeGestureDelete)
                touchHelper.attachToRecyclerView(recycler)

                recycler.adapter = postAdapter





            }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.menu_item,menu)
        val search=menu?.findItem(R.id.search_action)
        val searchView=search?.actionView as SearchView

        searchView.queryHint="Search tags"

        searchView.setOnQueryTextListener(object: SearchView. OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean{
                println(pListFull.size)
                println(temppListFull.size)
                temppListFull.clear()
                println(pListFull.size)
                return true
            }
            override fun onQueryTextChange(newText:String?): Boolean
            {
                println(pListFull.size)
                println(pListFull)
                temppListFull.clear()
                tempoListFull.clear()




                val searchText = newText!!.lowercase(Locale.getDefault())
                println(searchText)


                if(searchText.isNotEmpty()) {
                    pListFull.forEachIndexed { index, post ->

                        println(post)


                        if(post.tags.contains(searchText)){


                            temppListFull.add(post)
                            tempoListFull.add(oListFull[index])

                        }
                    }

                    recycler.adapter!!.notifyDataSetChanged()



                }
                else{



                    tempoListFull.addAll(oListFull)
                   temppListFull.addAll(pListFull)
                    recycler.adapter!!.notifyDataSetChanged()
                }

                return false
            }

            })

        return super.onCreateOptionsMenu(menu)
    }

}
