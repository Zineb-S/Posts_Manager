package com.ynov.postmanager

import com.google.gson.annotations.SerializedName

data class Post(


    val id : String,
    val image: String,
    val likes: Int,
    val tags: List<String>,
    val link: String,
    val text: String,
    val publishDate: String,
    //val owner: User
)
