package com.ynov.postmanager

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import okhttp3.*
import java.io.IOException
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

class PostAdapter (private var pList: MutableList<Post>,private var oList: MutableList<User>)  : RecyclerView.Adapter<PostAdapter.ViewHolder> () {


    private lateinit var mListener: OnItemClickListener

    interface OnItemClickListener{
        fun onItemClick(position : Int)
    }


    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the monster_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.post_item, parent, false)

        return ViewHolder(view,mListener)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {


        // get the data
        println("POSITION : "+position + " : "+ pList[position].id)
        val post = pList[position]
        val owner = oList[position]

        // assign the data to the corresponding UI element

        holder.ownerNameTextView.text = owner.firstName +" "+ owner.lastName
        //val dateFormat = SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")

        val outputFormat: DateFormat = SimpleDateFormat("dd yyyy HH:mm:ss ")
        val inputFormat: DateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")

        val inputText = post.publishDate
        val date: Date = inputFormat.parse(inputText)
        val outputText: String = outputFormat.format(date)

        //val dateFormat = SimpleDateFormat( "dd-yyyy HH:mm")

        val month_date = SimpleDateFormat("MMMM")
        val month_name = month_date.format(date)

        holder.postDateTextView.text = month_name+" "+outputText
        holder.postContentTextView.text = post.text
        var tagString = ""
        for (item in post.tags) {
            tagString += " #"
            tagString+=item

        }
        holder.tagsTextView.text =tagString
        Picasso.get().load(post.image).into(holder.postImageView)
        Picasso.get().load(owner.picture).into(holder.profileImageView)
        val context = holder.postDateTextView.context

    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return pList.size
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        mListener = listener
    }

    fun deleteItem(i: Int) {


        val client = OkHttpClient()

        notifyDataSetChanged()

        val request = Request.Builder()
            .url("https://dummyapi.io/data/v1/post/"+pList[i].id+"") //?page=2&limit=10?
            .addHeader("app-id","626474e1de86af0db21ad0d0")
            .delete()
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!response.isSuccessful) throw IOException("Unexpected code $response")
                    for ((name, value) in response.headers) {
                        println("$name: $value")
                    }

                    println(response.body!!.string())


                }


            }


        })


        pList.removeAt(i)
        oList.removeAt(i)

    }


    // Holds the views for adding it to image and text
     class ViewHolder(ItemView: View , listener: OnItemClickListener) : RecyclerView.ViewHolder(ItemView)  {
        val profileImageView = itemView.findViewById<ImageView>(R.id.profileImageView)
        val ownerNameTextView = itemView.findViewById<TextView>(R.id.ownerNameTextView)
        val postDateTextView = itemView.findViewById<TextView>(R.id.postDateTextView)
        val postImageView = itemView.findViewById<ImageView>(R.id.postImageView)
        val postContentTextView = itemView.findViewById<TextView>(R.id.postContentTextView)
        val tagsTextView = itemView.findViewById<TextView>(R.id.tagsTextView)

        init {
            itemView.setOnClickListener{
                listener.onItemClick(absoluteAdapterPosition)


            }

        }
    }





}