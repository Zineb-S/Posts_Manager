package com.ynov.postmanager

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.squareup.picasso.Picasso
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

class PostDetails : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.post_details)

        val ownerImageView = findViewById<ImageView>(R.id.postOwnerImageViewDetail)
        val ownerTextView = findViewById<TextView>(R.id.postOwnerTextViewDetail)
        val postContentTextView = findViewById<TextView>(R.id.postContentTextViewDetail)
        val postImageView = findViewById<ImageView>(R.id.postImageViewDetail)
        val postLikesTextView = findViewById<TextView>(R.id.likesTextView)
        val postTagsTextView = findViewById<TextView>(R.id.tagsTextViewDetail)
        val postPublishedDateTextView = findViewById<TextView>(R.id.publishedDateTextViewDetail)


        val ownerPic = intent.getStringExtra("ownerPic")
        val ownerName = intent.getStringExtra("ownerName")
        val postContent = intent.getStringExtra("postContent")
        val postPicture = intent.getStringExtra("postPicture")
        val postLikes = intent.getIntExtra("postLikes",0)
        val postTags = intent.getStringArrayListExtra("postTags")
        val postDate = intent.getStringExtra("postDate")

        Picasso.get().load(ownerPic).into(ownerImageView)
        Picasso.get().load(postPicture).into(postImageView)
        ownerTextView.text = ownerName
        postContentTextView.text = postContent
        postLikesTextView.text = postLikes.toString()

        val outputFormat: DateFormat = SimpleDateFormat("dd yyyy HH:mm:ss ")
        val inputFormat: DateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")

        val date: Date = inputFormat.parse(postDate)
        val outputText: String = outputFormat.format(date)

        //val dateFormat = SimpleDateFormat( "dd-yyyy HH:mm")

        val monthDate = SimpleDateFormat("MMMM")
        val monthName = monthDate.format(date)

        postPublishedDateTextView.text = monthName+" "+outputText

        var tagString = ""
        if (postTags != null) {
            for (item in postTags) {
                tagString += " #"
                tagString+=item

            }
        }

        postTagsTextView.text = tagString




    }

}